(function() {
    var wasm;
    const __exports = {};


    let cachegetUint8Memory = null;
    function getUint8Memory() {
        if (cachegetUint8Memory === null || cachegetUint8Memory.buffer !== wasm.memory.buffer) {
            cachegetUint8Memory = new Uint8Array(wasm.memory.buffer);
        }
        return cachegetUint8Memory;
    }

    function getrandom(array) {
      return window.crypto.getRandomValues(array);
    }

    function getArrayU8FromWasm(ptr, len) {
        return getUint8Memory().subarray(ptr / 1, ptr / 1 + len);
    }

    function passArray8ToWasm(arg) {
        const ptr = wasm.__wbindgen_malloc(arg.length * 1);
        getUint8Memory().set(arg, ptr / 1);
        return [ptr, arg.length];
    }

    let cachegetUint32Memory = null;
    function getUint32Memory() {
        if (cachegetUint32Memory === null || cachegetUint32Memory.buffer !== wasm.memory.buffer) {
            cachegetUint32Memory = new Uint32Array(wasm.memory.buffer);
        }
        return cachegetUint32Memory;
    }

    __exports.__wbg_getrandom_be47e1dfff6247dd = function(ret, arg0, arg1) {
        let varg0 = getArrayU8FromWasm(arg0, arg1);

        varg0 = varg0.slice();
        wasm.__wbindgen_free(arg0, arg1 * 1);


        const [retptr, retlen] = passArray8ToWasm(getrandom(varg0));
        const mem = getUint32Memory();
        mem[ret / 4] = retptr;
        mem[ret / 4 + 1] = retlen;

    };

    let cachedGlobalArgumentPtr = null;
    function globalArgumentPtr() {
        if (cachedGlobalArgumentPtr === null) {
            cachedGlobalArgumentPtr = wasm.__wbindgen_global_argument_ptr();
        }
        return cachedGlobalArgumentPtr;
    }

    let cachedEncoder = new TextEncoder('utf-8');

    function passStringToWasm(arg) {

        const buf = cachedEncoder.encode(arg);
        const ptr = wasm.__wbindgen_malloc(buf.length);
        getUint8Memory().set(buf, ptr);
        return [ptr, buf.length];
    }

    let cachedDecoder = new TextDecoder('utf-8');

    function getStringFromWasm(ptr, len) {
        return cachedDecoder.decode(getUint8Memory().subarray(ptr, ptr + len));
    }

    function freeSrdJsResult(ptr) {

        wasm.__wbg_srdjsresult_free(ptr);
    }
    /**
    */
    class SrdJsResult {

        static __wrap(ptr) {
            const obj = Object.create(SrdJsResult.prototype);
            obj.ptr = ptr;

            return obj;
        }

        free() {
            const ptr = this.ptr;
            this.ptr = 0;
            freeSrdJsResult(ptr);
        }
        /**
        * @returns {Uint8Array}
        */
        output_data() {
            const retptr = globalArgumentPtr();
            wasm.srdjsresult_output_data(retptr, this.ptr);
            const mem = getUint32Memory();
            const rustptr = mem[retptr / 4];
            const rustlen = mem[retptr / 4 + 1];

            const realRet = getArrayU8FromWasm(rustptr, rustlen).slice();
            wasm.__wbindgen_free(rustptr, rustlen * 1);
            return realRet;

        }
        /**
        * @returns {number}
        */
        res_code() {
            return wasm.srdjsresult_res_code(this.ptr);
        }
    }
    __exports.SrdJsResult = SrdJsResult;

    function freeSrdBlob(ptr) {

        wasm.__wbg_srdblob_free(ptr);
    }
    /**
    */
    class SrdBlob {

        static __wrap(ptr) {
            const obj = Object.create(SrdBlob.prototype);
            obj.ptr = ptr;

            return obj;
        }

        free() {
            const ptr = this.ptr;
            this.ptr = 0;
            freeSrdBlob(ptr);
        }
        /**
        * @param {string} arg0
        * @param {Uint8Array} arg1
        * @returns {SrdBlob}
        */
        static new(arg0, arg1) {
            const [ptr0, len0] = passStringToWasm(arg0);
            const [ptr1, len1] = passArray8ToWasm(arg1);
            try {
                return SrdBlob.__wrap(wasm.srdblob_new(ptr0, len0, ptr1, len1));

            } finally {
                wasm.__wbindgen_free(ptr0, len0 * 1);
                wasm.__wbindgen_free(ptr1, len1 * 1);

            }

        }
        /**
        * @returns {string}
        */
        blob_type_copy() {
            const retptr = globalArgumentPtr();
            wasm.srdblob_blob_type_copy(retptr, this.ptr);
            const mem = getUint32Memory();
            const rustptr = mem[retptr / 4];
            const rustlen = mem[retptr / 4 + 1];

            const realRet = getStringFromWasm(rustptr, rustlen).slice();
            wasm.__wbindgen_free(rustptr, rustlen * 1);
            return realRet;

        }
        /**
        * @returns {Uint8Array}
        */
        data_copy() {
            const retptr = globalArgumentPtr();
            wasm.srdblob_data_copy(retptr, this.ptr);
            const mem = getUint32Memory();
            const rustptr = mem[retptr / 4];
            const rustlen = mem[retptr / 4 + 1];

            const realRet = getArrayU8FromWasm(rustptr, rustlen).slice();
            wasm.__wbindgen_free(rustptr, rustlen * 1);
            return realRet;

        }
        /**
        * @param {string} arg0
        * @param {string} arg1
        * @returns {SrdBlob}
        */
        static new_logon(arg0, arg1) {
            const [ptr0, len0] = passStringToWasm(arg0);
            const [ptr1, len1] = passStringToWasm(arg1);
            try {
                return SrdBlob.__wrap(wasm.srdblob_new_logon(ptr0, len0, ptr1, len1));

            } finally {
                wasm.__wbindgen_free(ptr0, len0 * 1);
                wasm.__wbindgen_free(ptr1, len1 * 1);

            }

        }
    }
    __exports.SrdBlob = SrdBlob;

    function freeSrd(ptr) {

        wasm.__wbg_srd_free(ptr);
    }
    /**
    */
    class Srd {

        free() {
            const ptr = this.ptr;
            this.ptr = 0;
            freeSrd(ptr);
        }
        /**
        * @param {SrdBlob} arg0
        * @returns {void}
        */
        set_raw_blob(arg0) {
            const ptr0 = arg0.ptr;
            if (ptr0 === 0) {
                throw new Error('Attempt to use a moved value');
            }
            arg0.ptr = 0;
            return wasm.srd_set_raw_blob(this.ptr, ptr0);
        }
        /**
        * @param {boolean} arg0
        * @returns {}
        */
        constructor(arg0) {
            this.ptr = wasm.srd_new(arg0 ? 1 : 0);
        }
        /**
        * @param {Uint8Array} arg0
        * @returns {SrdJsResult}
        */
        authenticate(arg0) {
            const [ptr0, len0] = passArray8ToWasm(arg0);
            try {
                return SrdJsResult.__wrap(wasm.srd_authenticate(this.ptr, ptr0, len0));

            } finally {
                wasm.__wbindgen_free(ptr0, len0 * 1);

            }

        }
        /**
        * @returns {Uint8Array}
        */
        get_delegation_key() {
            const retptr = globalArgumentPtr();
            wasm.srd_get_delegation_key(retptr, this.ptr);
            const mem = getUint32Memory();
            const rustptr = mem[retptr / 4];
            const rustlen = mem[retptr / 4 + 1];

            const realRet = getArrayU8FromWasm(rustptr, rustlen).slice();
            wasm.__wbindgen_free(rustptr, rustlen * 1);
            return realRet;

        }
        /**
        * @returns {Uint8Array}
        */
        get_integrity_key() {
            const retptr = globalArgumentPtr();
            wasm.srd_get_integrity_key(retptr, this.ptr);
            const mem = getUint32Memory();
            const rustptr = mem[retptr / 4];
            const rustlen = mem[retptr / 4 + 1];

            const realRet = getArrayU8FromWasm(rustptr, rustlen).slice();
            wasm.__wbindgen_free(rustptr, rustlen * 1);
            return realRet;

        }
        /**
        * @param {Uint8Array} arg0
        * @returns {void}
        */
        set_cert_data(arg0) {
            const [ptr0, len0] = passArray8ToWasm(arg0);
            return wasm.srd_set_cert_data(this.ptr, ptr0, len0);
        }
    }
    __exports.Srd = Srd;

    __exports.__wbindgen_throw = function(ptr, len) {
        throw new Error(getStringFromWasm(ptr, len));
    };

    function init(wasm_path) {
        const fetchPromise = fetch(wasm_path);
        let resultPromise;
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            resultPromise = WebAssembly.instantiateStreaming(fetchPromise, { './sardine': __exports });
        } else {
            resultPromise = fetchPromise
            .then(response => response.arrayBuffer())
            .then(buffer => WebAssembly.instantiate(buffer, { './sardine': __exports }));
        }
        return resultPromise.then(({instance}) => {
            wasm = init.wasm = instance.exports;
            return;
        });
    };
    self.wasm_bindgen = Object.assign(init, __exports);
})();
