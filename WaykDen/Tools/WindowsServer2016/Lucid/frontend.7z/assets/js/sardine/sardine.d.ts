/* tslint:disable */
export class SrdJsResult {
free(): void;
 output_data(): Uint8Array;

 res_code(): number;

}
export class SrdBlob {
free(): void;
static  new(arg0: string, arg1: Uint8Array): SrdBlob;

 blob_type_copy(): string;

 data_copy(): Uint8Array;

static  new_logon(arg0: string, arg1: string): SrdBlob;

}
export class Srd {
free(): void;
 set_raw_blob(arg0: SrdBlob): void;

 constructor(arg0: boolean);

 authenticate(arg0: Uint8Array): SrdJsResult;

 get_delegation_key(): Uint8Array;

 get_integrity_key(): Uint8Array;

 set_cert_data(arg0: Uint8Array): void;

}
